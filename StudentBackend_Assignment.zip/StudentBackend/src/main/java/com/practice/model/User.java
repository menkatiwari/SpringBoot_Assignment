package com.practice.model;



public class User {
	private Long id;
	private String username;
	private String namr;
	private String email;

}
